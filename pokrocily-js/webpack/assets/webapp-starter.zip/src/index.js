import './index.html';

console.log('funguju');
