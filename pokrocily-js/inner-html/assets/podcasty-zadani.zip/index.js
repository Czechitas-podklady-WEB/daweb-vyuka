'use strict';

const num = '126';
const title = 'Robot, který snědl koblihu';
const guest = 'Radovan Siwek';

console.log('funguju!');