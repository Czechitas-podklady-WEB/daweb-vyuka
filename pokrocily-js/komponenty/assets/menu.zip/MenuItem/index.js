'use strict';

const menuItemTemplate = Handlebars.compile(
  // Zde vyberte z HTML obsah šablony
);

const renderMenuItem = (item) => {

};