'use strict';

const likeBtn = document.querySelector('#like-btn');
likeBtn.addEventListener('click', () => {
  likeBtn.classList.toggle('like-btn--on');
});
