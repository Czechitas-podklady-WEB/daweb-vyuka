import './style.css';
import './index.html';

const roll = () => {
  return Math.floor(Math.random() * 6) + 1;
};

console.log('funguju!');
