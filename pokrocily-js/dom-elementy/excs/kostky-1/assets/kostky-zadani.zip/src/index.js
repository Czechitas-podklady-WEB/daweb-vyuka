import './style.css';

const roll = () => {
  return Math.floor(Math.random() * 6) + 1;
};

console.log('funguju!');
