import './style.css';
import './index.html';

console.log('funguju!');
