<template>
  <div class="container">
    <h1>Já jsem Vue aplikace</h1>
    <div class="counter">25</div>
  </div>
</template>

<script>
export default {
  name: 'App',
};
</script>

<style lang="css">
* {
  box-sizing: border-box;
}

html {
  font-family: sans-serif;
}

.counter {
  width: 3rem;
  height: 3rem;
  margin: 1rem 2rem;
  line-height: 3rem;
  text-align: center;
  font-size: 1.8rem;
  border-radius: 0.5rem;
  color: white;
  background-color: orange;
}

</style>