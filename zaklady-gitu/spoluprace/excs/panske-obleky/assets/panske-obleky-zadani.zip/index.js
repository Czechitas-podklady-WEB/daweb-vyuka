'use strict';

console.log('funguju');
