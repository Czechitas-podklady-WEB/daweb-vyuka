let names=[
'john',
'peter',
'helen'
]
console.log(names)
