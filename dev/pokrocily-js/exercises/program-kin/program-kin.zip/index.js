'use strict';

const movieTemplate = Handlebars.compile(
  'Film {{title}} začíná v {{time}}, sál číslo {{hall}}'
);

const movie1 = {
  title: 'Casablanca',
  time: '19:30',
  hall: 7,
};