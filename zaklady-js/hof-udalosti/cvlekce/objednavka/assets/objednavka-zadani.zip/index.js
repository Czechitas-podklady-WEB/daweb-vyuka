'use strict';

console.log('it works');
