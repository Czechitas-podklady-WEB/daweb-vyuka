'use strict';

const users = [
  'petr',
  'jana-34',
  'husky16',
  '66beruska',
  'thegodofU',
  'rene_gade',
  'tommy',
  'luciluci',
  'tanko',
  'poltergeist',
  'hlava-havla',
  'telo-ramba'
];

