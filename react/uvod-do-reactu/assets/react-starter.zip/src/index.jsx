import React from 'react';
import { render } from 'react-dom';
import './index.html';

render(<h1>React Starter</h1>, document.querySelector('#app'));
