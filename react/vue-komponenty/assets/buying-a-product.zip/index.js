'use strict';

const handleClick = () => {
  const btnElm = document.querySelector('#buy-btn');
  const quantityElm = document.querySelector('#quantity');
  const quantity = Number(quantityElm.value);
  btnElm.textContent = quantity + ' kusů v košíku';
  btnElm.classList.add('btn--done');
}