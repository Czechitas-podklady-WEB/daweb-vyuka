---
title: Úkol na scpecificitu a CSS selektory
demand: 3
---

Stáhněte si z toho adresáře zip "kod-cviceni-specificita.zip".

## Proveďte následující úpravy:

### Úprava CSS selektorů

- Upravte kód jen v souboru override.css.
- Dostali jste CSS soubor od bývalého kolegy. Ten používal pro přetížení CSS selektoru klíčové slovo "!important" na konci specifických CSS řádků.
- CSS pravidla s "!important" ale vyhrávají vždy nad ostatními a vy je pak nedokážete přetížít.

- Vymažte všechna klíčová slova "!important" a upravte CSS sekektory tak, aby daná CSS pravidla fungovala na naší stránce.
- Stránka pak bude vypadat tak, jako na začátku, než jste začaly s kódem pracovat.
